﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Queue<Employee> myzchina = new Queue<Employee>();
            Queue<Employee> zenchina = new Queue<Employee>();
 

            List<Employee> employees = new List<Employee>();

            using (StreamReader sr = File.OpenText("employees.txt"))
            {
                string line;
                while (!sr.EndOfStream)
                {
                    line = sr.ReadLine();
                    string[] data = line.Split(' ');

                    Employee emp = new Employee
                    {
                        Familiya = data[0],
                        Imya = data[1],
                        Otchestvo = data[2],
                        Pol = data[3],
                        Age = int.Parse(data[4]),
                        Zarplata = int.Parse(data[5])
                    };
                    employees.Add(emp);
                }
            }

            myzchina = new Queue<Employee>(employees.Where(emp => emp.Pol == "Мужчина").ToList());
            zenchina = new Queue<Employee>(employees.Where(emp => emp.Pol == "Женщина").ToList());

            listBox1.Items.Add("Данные о мужчинах:");
            Queue(myzchina);

            listBox1.Items.Add("\nДанные о женщинах:");
            Queue(zenchina); 
        }

        private void Queue(Queue<Employee> queue)
        {
            foreach (var emp in queue)
            {
                listBox1.Items.Add($"{emp.Familiya} {emp.Imya} {emp.Otchestvo}, {emp.Age} лет, зарплата: {emp.Zarplata}");
            }
        }
    }
    
}
