﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string formula = "m (9, p (p (3,5), m (3,8)))";
            listBox1.Items.Add($"Формула {formula} =  {Formula(formula)}");
        }

        private int Formula(string formula)
        {
            Stack<object> stack = new Stack<object>();

            foreach (char c in formula)
            {
                if (char.IsDigit(c))
                {
                    stack.Push(int.Parse(c.ToString()));
                }
                else if (c == 'm' || c == 'p')
                {
                    stack.Push(c);
                }
                else if (c == ',')
                {
                    continue;
                }
                else if (c == ')')
                {
                    int b = (int)stack.Pop();
                    int a = (int)stack.Pop();
                    char opera = (char)stack.Pop();
                    int result;
                    if (opera == 'm')
                    {
                        result = (a - b) % 10;
                    }
                    else
                    {
                        result = (a + b) % 10;
                    }
                    stack.Push(result);
                }
            }
            return (int)stack.Pop();
        }
    }
}
