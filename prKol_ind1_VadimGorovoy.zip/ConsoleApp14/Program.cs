﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    class Program
    {
        static void Main(string[] args)
        {
            string infix_virashenie = "A+B-C";
            string prefix_virashenie = InfixToPrefix(infix_virashenie);
            Console.WriteLine("Инфиксная форма: " + infix_virashenie);
            Console.WriteLine("Префиксная форма: " + prefix_virashenie);
            Console.Read();
        }

        static string InfixToPrefix(string infix_virashenie)
        {
            Stack<char> stack = new Stack<char>();
            string prefix_virashenie = "";

            infix_virashenie = string.Concat(infix_virashenie.Reverse());

            foreach (char c in infix_virashenie)
            {
                if (char.IsLetterOrDigit(c))
                {
                    prefix_virashenie = c + prefix_virashenie;
                }
                else if (c == ')')
                {
                    stack.Push(c);
                }
                else if (c == '(')
                {
                    while (stack.Count > 0 && stack.Peek() != ')')
                    {
                        prefix_virashenie = stack.Pop() + prefix_virashenie;
                    }

                    stack.Pop();
                }
                else
                {
                    while (stack.Count > 0 && Prioritet(c) < Prioritet(stack.Peek()))
                    {
                        prefix_virashenie = stack.Pop() + prefix_virashenie;
                    }

                    stack.Push(c);
                }
            }

            while (stack.Count > 0)
            {
                prefix_virashenie = stack.Pop() + prefix_virashenie;
            }

            return prefix_virashenie;
        }

        static int Prioritet(char op)
        {
            switch (op)
            {
                case '+':
                case '-':
                    return 1;
                case '*':
                case '/':
                    return 2;
                case '^':
                    return 3;
                default:
                    return 0;
            }
        }
    }
}
