﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp15
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5; 
            int b = 10; 

            Queue<int> range = new Queue<int>(); 
            Queue<int> menche_a = new Queue<int>(); 
            Queue<int> bolche_b = new Queue<int>(); 

            using (StreamReader sr = File.OpenText("chisla.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    int number = int.Parse(line);

                    if (number >= a && number <= b)
                    {
                        range.Enqueue(number);
                    }
                    else if (number < a)
                    {
                        menche_a.Enqueue(number);
                    }
                    else
                    {
                        bolche_b.Enqueue(number);
                    }
                }
            }

            Console.WriteLine($"Числа из интервала [{a}, {b}]:");
            Queue(range);

            Console.WriteLine("\nЧисла меньше a:");
            Queue(menche_a);

            Console.WriteLine("\nЧисла больше b:");
            Queue(bolche_b);
            Console.Read();
        }

        static void Queue(Queue<int> queue)
        {
            foreach (int number in queue)
            {
                Console.WriteLine(number);
            }
        }
    }
}
